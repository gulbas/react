// note_routes.js
const Comment = require('../../models/comment');
let ObjectID = require('mongodb').ObjectID;
module.exports = function (app, db) {
    app.get('/notes', (req, res) => {
        Comment.find({}, (err, result) => {
            if (!err && result) {
                res.status(200).json(result)
            } else {
                res.status(404).send('not found');
            }
        })
    });
    app.get('/notes/:id', (req, res) => {
        const id = req.params.id;
        const details = {'_id': new ObjectID(id)};
        db.collection('notes').findOne(details, (err, item) => {
            if (err) {
                res.send({'error': 'An error has occurred'});
            } else {
                res.send(item);
            }
        });
    });
    app.post('/notes', (req, res) => {
        const note = {author: req.body.author, comment: req.body.comment};
        db.collection('notes').insert(note, (err, result) => {
            if (err) {
                res.send({'error': 'An error has occurred'});
            } else {
                res.send(result.ops[0]);
            }
        });
    });
};