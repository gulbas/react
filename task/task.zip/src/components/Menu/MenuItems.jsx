export const menuItems = [
    {
        id: 1, link: '/', title: 'Main'
    },
    {
        id: 2, link: '/blog', title: 'Blog'
    },
    {
        id: 3, link: '/users', title: 'User'
    },
    {
        id: 4, link: '/comments', title: 'Comments'
    },
    {
        id: 5, link: '/clock', title: 'Clock'
    }
];