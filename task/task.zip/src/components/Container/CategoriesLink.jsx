export const linkPart1 = [
    {
        link: '#', title: 'Web Design', id: 1
    },
    {
        link: '#', title: 'HTML', id: 2
    },
    {
        link: '#', title: 'Freebies', id: 3
    }
];

export const linkPart2 = [
    {
        link: '#', title: 'JavaScript', id: 4
    },
    {
        link: '#', title: 'CSS', id: 5
    },
    {
        link: '#', title: 'Tutorials', id: 6
    }
];






