module.exports = {
    plugin: [
        require('autoprefixer')
    ]
}