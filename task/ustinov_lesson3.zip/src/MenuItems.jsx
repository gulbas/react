export const menuItems = [
  {
    link: 'https://geekbrains.ru', title: 'Geekbrains'
  },
  {
    link: 'https://t.me/joinchat/CRh7yBKGg5g2f0ZvhhkoVQ', title: 'Chat React in telegram'
  },
  {
    link: 'https://github.com/gulbas', title: 'Github'
  }
];